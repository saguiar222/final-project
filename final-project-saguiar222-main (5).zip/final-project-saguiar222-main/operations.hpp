#ifndef _operations_hpp_
#define _operations_hpp_

#include <forward_list>
#include <list>
#include <map>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "book.hpp"

//
// INSERT OPERATIONS
//

struct insert_at_back_of_vector {
  // Function takes a constant Book as a parameter, inserts that book at the
  // back of a vector, and returns nothing.
  void operator()(const Book& book) {
      my_vector.push_back(book);
  }

  std::vector<Book>& my_vector;
};

struct insert_at_back_of_dll {
  // Function takes a constant Book as a parameter, inserts that book at the
  // back of a doubly linked list, and returns nothing.
  void operator()(const Book& book) {
      my_dll.push_back(book);
  }

  std::list<Book>& my_dll;
};

struct insert_at_back_of_sll {
  // Function takes a constant Book as a parameter, inserts that book at the
  // back of a singly linked list, and returns nothing.
  void operator()(const Book& book) {
      if (my_sll.empty()) {
          my_sll.insert_after(my_sll.before_begin(), book);
          return;
      }
      std::forward_list<Book>::iterator it = my_sll.begin();
      while (std::next(it) != my_sll.end()) {
          it = std::next(it);
      }
      my_sll.insert_after(it, book);
  }

  std::forward_list<Book>& my_sll;
};

struct insert_at_front_of_vector {
  // Function takes a constant Book as a parameter, inserts that book at the
  // front of a vector, and returns nothing.
  void operator()(const Book& book) {
      my_vector.insert(my_vector.begin(), book);
  }

  std::vector<Book>& my_vector;
};

struct insert_at_front_of_dll {
  // Function takes a constant Book as a parameter, inserts that book at the
  // front of a doubly linked list, and returns nothing.
  void operator()(const Book& book) {
      my_dll.push_front(book);
  }

  std::list<Book>& my_dll;
};

struct insert_at_front_of_sll{
  // Function takes a constant Book as a parameter, inserts that book at the
  // front of a singly linked list, and returns nothing.
  void operator()(const Book& book) {
      my_sll.push_front(book);
  }

  std::forward_list<Book>& my_sll;
};

struct insert_into_bst {
  // Function takes a constant Book as a parameter, inserts that book indexed by
  // the book's ISBN into a binary search tree, and returns nothing.
  void operator()(const Book& book) {
      my_bst.insert(std::pair<std::string, Book>(book.isbn(), book));
  }

  std::map<std::string, Book>& my_bst;
};

struct insert_into_hash_table {
  // Function takes a constant Book as a parameter, inserts that book indexed by
  // the book's ISBN into a hash table, and returns nothing.
  void operator()(const Book& book) {
      my_hash_table.insert(std::pair<std::string, Book>(book.isbn(), book));
  }

  std::unordered_map<std::string, Book>& my_hash_table;
};

//
// REMOVE OPERATIONS
//

struct remove_from_back_of_vector {
  // Function takes no parameters, removes the book at the back of a vector, and
  // returns nothing.
  void operator()(const Book& unused) {
      if (!my_vector.empty()) {
          my_vector.pop_back();
      }
      else throw std::out_of_range("Cannot remove from an empty structure");
  }

  std::vector<Book>& my_vector;
};

struct remove_from_back_of_dll {
  // Function takes no parameters, removes the book at the back of a doubly
  // linked list, and returns nothing.
  void operator()(const Book& unused) {
      if (!my_dll.empty()) {
          my_dll.pop_back();
      }
      else throw std::out_of_range("Cannot remove from an empty structure");
  }

  std::list<Book>& my_dll;
};

struct remove_from_back_of_sll {
  // Function takes no parameters, removes the book at the back of a singly
  // linked list, and returns nothing.
  void operator()(const Book& unused) {
      if (!my_sll.empty()) {
          std::forward_list<Book>::iterator current = my_sll.begin();
          std::forward_list<Book>::iterator predecessor = my_sll.before_begin();
          current = std::next(current);
          while (current != my_sll.end()) {
              current = std::next(current);
              predecessor = std::next(predecessor);
          }
          if (current == my_sll.end()) {
              my_sll.erase_after(predecessor);
          }
      }
      else throw std::out_of_range("Cannot remove from an empty structure");
  }

  std::forward_list<Book>& my_sll;
};

struct remove_from_front_of_vector {
  // Function takes no parameters, removes the book at the front of a vector,
  // and returns nothing.
  void operator()(const Book& unused) {
      if (!my_vector.empty()) {
          my_vector.erase(my_vector.begin());
      }
      else throw std::out_of_range("Cannot remove from an empty structure");
  }

  std::vector<Book>& my_vector;
};

struct remove_from_front_of_dll {
  // Function takes no parameters, removes the book at the front of a doubly
  // linked list, and returns nothing.
  void operator()(const Book& unused) {
      if (!my_dll.empty()) {
          my_dll.erase(my_dll.begin());
      }
      else throw std::out_of_range("Cannot remove from an empty structure");
  }

  std::list<Book>& my_dll;
};

struct remove_from_front_of_sll {
  // Function takes no parameters, removes the book at the front of a singly
  // linked list, and returns nothing.
  void operator()(const Book& unused) {
      if (!my_sll.empty()) {
          my_sll.pop_front();
      }
      else throw std::out_of_range("Cannot remove from an empty structure");
  }

  std::forward_list<Book>& my_sll;
};

struct remove_from_bst {
  // Function takes a constant Book as a parameter, finds and removes from the
  // binary search tree the book with a matching ISBN (if any), and returns
  // nothing. If no Book matches the ISBN, the method does nothing.
  void operator()(const Book& book) {
      my_bst.erase(book.isbn());
  }

  std::map<std::string, Book>& my_bst;
};

struct remove_from_hash_table {
  // Function takes a constant Book as a parameter, finds and removes from the
  // hash table the book with a matching ISBN (if any), and returns nothing. If
  // no Book matches the ISBN, the method does nothing.
  void operator()(const Book& book) {
      my_hash_table.erase(book.isbn());
  }

  std::unordered_map<std::string, Book>& my_hash_table;
};

//
// SEARCH OPERATIONS
//

struct search_within_vector {
  // Function takes no parameters, searches a vector for a book with an ISBN
  // matching the target ISBN, and returns a pointer to that found book if such
  // a book is found, nullptr otherwise.
  Book* operator()(const Book& unused) {
      if (!my_vector.empty()) {
          std::vector<Book>::iterator it = my_vector.begin();
          while (std::next(it) != my_vector.end()) {
              if ((*it).isbn() == target_isbn) {
                  return &(*it);
              }
              it = std::next(it);
          }
      }
      return nullptr;
  }

  std::vector<Book>& my_vector;
  const std::string target_isbn;
};

struct search_within_dll {
  // Function takes no parameters, searches a doubly linked list for a book with
  // an ISBN matching the target ISBN, and returns a pointer to that found book
  // if such a book is found, nullptr otherwise.
  Book* operator()(const Book& unused) {
      if (!my_dll.empty()) {
          std::list<Book>::iterator it = my_dll.begin();
          while (std::next(it) != my_dll.end()) {
              if ((*it).isbn() == target_isbn) {
                  return &(*it);
              }
              it = std::next(it);
          }
      }
      return nullptr;
  }

  std::list<Book>& my_dll;
  const std::string target_isbn;
};

struct search_within_sll {
  // Function takes no parameters, searches a singly linked list for a book with
  // an ISBN matching the target ISBN, and returns a pointer to that found book
  // if such a book is found, nullptr otherwise.
  Book* operator()(const Book& unused) {
      if (!my_sll.empty()) {
          std::forward_list<Book>::iterator it = my_sll.begin();
          while (std::next(it) != my_sll.end()) {
              if ((*it).isbn() == target_isbn) {
                  return &(*it);
              }
              it = std::next(it);
          }
      }
      return nullptr;
  }

  std::forward_list<Book>& my_sll;
  const std::string target_isbn;
};

struct search_within_bst {
  // Function takes no parameters, searches a binary search tree for a book with
  // an ISBN matching the target ISBN, and returns a pointer to that found book
  // if such a book is found, nullptr otherwise.
  Book* operator()(const Book& unused) {
      std::map<std::string, Book>::iterator it = my_bst.find(target_isbn);
      if (it == my_bst.end())
          return nullptr;
      return &(*it).second;
  }

  std::map<std::string, Book>& my_bst;
  const std::string target_isbn;
};

struct search_within_hash_table {
  // Function takes no parameters, searches a hash table for a book with an ISBN
  // matching the target ISBN, and returns a pointer to that found book if such
  // a book is found, nullptr otherwise.
  Book* operator()(const Book& unused) {
      std::unordered_map<std::string, Book>::iterator it = my_hash_table.find(target_isbn);
      if (it == my_hash_table.end())
          return nullptr;
      return &(*it).second;

  }

  std::unordered_map<std::string, Book>& my_hash_table;
  const std::string target_isbn;
};

#endif
