# Final Project: Container Analysis and Comparison

## Information

Name: Ada Lovelace

Email: adalovelace@csu.fullerton.edu

Section: CPSC 131 - Section 03

Analysis Document Link: https://docs.google.com/document/d/1qfSJA8oD3_cpIqxJeWuRmZP6rkR9fSdDdLt5yjCRPQ4

Google Sheets Link: Optional